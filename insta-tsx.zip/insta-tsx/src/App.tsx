import React from 'react';

import Insta from './component/insta';


class App extends React.Component {
  
    render(){
      return(
        <div>
        <Insta />
        </div>
      )
    }
  }

  

export default App;

